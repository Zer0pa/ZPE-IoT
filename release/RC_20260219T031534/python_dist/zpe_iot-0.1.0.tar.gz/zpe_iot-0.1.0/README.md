# zpe-iot Python Package

`zpe-iot` provides deterministic sensor compression for IoT time-series.

## Install

```bash
pip install zpe-iot
```

## CLI

```bash
zpe-iot --help
zpe-iot compress input.csv --preset vibration --output out.zpk
zpe-iot info out.zpk
zpe-iot decompress out.zpk --output restored.csv
zpe-iot benchmark input.csv --compare zstd,lz4,zlib
```

## API

```python
import numpy as np
import zpe_iot

samples = np.sin(np.linspace(0, 20, 1024))
stream = zpe_iot.encode(samples, preset="vibration")
packet = stream.to_bytes()
restored = zpe_iot.decode(packet)
```
